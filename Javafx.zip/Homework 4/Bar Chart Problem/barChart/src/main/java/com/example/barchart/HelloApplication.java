package com.example.barchart;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {

        stage.setTitle("Random Bar Chart");

//        generate random data
        List<String> items = generateRandomItemsXAxis();
        String yAxisDescription = generateRandomDescriptionYAxis();
        List<Double> data = generateRandomData(items.size());

//        generate both x and y axis
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Devices");
        yAxis.setLabel(yAxisDescription);

//        create a barchart
        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("BarChart Experiments");

//        add data to the chart
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        for (int i = 0; i < items.size(); i++) {
            series.getData().add(new XYChart.Data<>(items.get(i), data.get(i)));
        }

//        Edit barchart
        barChart.getData().add(series);
        barChart.setBarGap(10);
        barChart.setCategoryGap(10);
        series.setName("2014");

//        scene
        Scene scene = new Scene(barChart, 400, 300);
        stage.setScene(scene);

        stage.show();

    }

//    Items in X axis
    private List<String> generateRandomItemsXAxis() {
        List<String> items = new ArrayList<>();
        items.add("Desktop");
        items.add("Phone");
        items.add("Tablet");
        return items;
    }

//    Description of Y axis
    private String generateRandomDescriptionYAxis() {
        String[] descriptions = {"Visits", "Sales", "Revenue", "Profit", "Expenses"};
        Random random = new Random();
        return descriptions[random.nextInt(descriptions.length)];
    }

//    Match data of each item in the X axis which corresponds to the Y axis
    private List<Double> generateRandomData(int size) {
        List<Double> data = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            data.add(random.nextDouble() * 1000); // Generating random values between 0 and 1000
        }
        return data;
    }

    public static void main(String[] args) {
        launch();
    }
}