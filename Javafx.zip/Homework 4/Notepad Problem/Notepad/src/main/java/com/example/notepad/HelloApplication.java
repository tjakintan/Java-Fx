package com.example.notepad;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.print.PrinterJob;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.security.Key;
import java.util.ServiceLoader;
import java.util.Stack;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;

import static javafx.scene.paint.Color.*;

public class HelloApplication extends Application {

    private String currentNoteName;
    private File currentFile;


    @Override
    public void start(Stage stage) throws IOException {
//        set default name
        currentNoteName = "Untitled";


//        TextArea
        TextArea textArea = new TextArea();


//        MenuBar
        MenuBar menuBar = new MenuBar();
//        set menubar background color
        menuBar.setBackground(new Background(new BackgroundFill(Color.GRAY,  CornerRadii.EMPTY, Insets.EMPTY)));

//        Buttons

//        File Button ->
        Menu file = new Menu("File");
//        File menu items
//        Actions of file item
        MenuItem newItem = new MenuItem("New");
        newItem.setOnAction(e -> newFile(textArea));
        MenuItem openItem = new MenuItem("Open...");
        openItem.setOnAction(e -> openFile(textArea));
        MenuItem saveItem = new MenuItem("Save");
        saveItem.setOnAction(e -> saveToFile(textArea));
        MenuItem saveAsItem = new MenuItem("Save As...");
        saveAsItem.setOnAction(e -> saveAsToFile(textArea.getText()));
        MenuItem pageSetupItem = new MenuItem("Page Setup...");
        MenuItem printItem = new Menu("Print");
        printItem.setOnAction(e -> {
            // Create a PrinterJob
            PrinterJob job = PrinterJob.createPrinterJob();
            if (job != null) {
                // Create a new TextArea to contain the text to print
                TextArea printedText = new TextArea(textArea.getText());

                // Print the text
                if (job.printPage(printedText)) {
                    job.endJob();
                }
            }
        });
        MenuItem exitItem = new MenuItem("Exit");
        exitItem.setOnAction(e -> Platform.exit());
//        add file menu items to file
        file.getItems().addAll(newItem, openItem, saveItem, saveAsItem, new SeparatorMenuItem(), pageSetupItem, printItem, new SeparatorMenuItem(), exitItem);
//        add file to menu bar
        menuBar.getMenus().add(file);




//        Menu Button ->
        Menu edit = new Menu("Edit");

//        Menu items
        MenuItem undoItem = new MenuItem("Undo");
        undoItem.setAccelerator(KeyCombination.keyCombination("Ctrl+Z"));
        undoItem.setOnAction(e -> {
            Stack<String> history = new Stack<>();
            history.push(textArea.getText());
            if (!history.isEmpty()) {
                // Get the last text from history and set it in the TextArea
                String lastText = history.pop();
                textArea.setText(lastText);
            }
        });
        MenuItem cutItem = new MenuItem("Cut");
        cutItem.setAccelerator(KeyCombination.keyCombination("Ctrl+X"));
        cutItem.setOnAction(e -> {
            String selectedText = textArea.getSelectedText();

            if (!selectedText.isEmpty()) {
                Clipboard clipboard = Clipboard.getSystemClipboard();
                ClipboardContent content = new ClipboardContent();
                content.putString(selectedText);
                clipboard.setContent(content);

                // Remove the selected text from the TextArea
                int start = textArea.getSelection().getStart();
                int end = textArea.getSelection().getEnd();
                textArea.replaceText(start, end, "");
            }
        });
        MenuItem copyItem = new MenuItem("Copy");
        copyItem.setAccelerator(KeyCombination.keyCombination("Ctrl+C"));
        copyItem.setOnAction(e -> {
            String selectedText = textArea.getSelectedText();
            if (!selectedText.isEmpty()) {
                Clipboard clipboard = Clipboard.getSystemClipboard();
                ClipboardContent content = new ClipboardContent();
                content.putString(selectedText);
                clipboard.setContent(content);
            }
        });
        MenuItem pasteItem = new MenuItem("Paste");
        pasteItem.setAccelerator(KeyCombination.keyCombination("Ctrl+V"));
        pasteItem.setOnAction(e -> {
            Clipboard clipboard = Clipboard.getSystemClipboard();
            if (clipboard.hasString()) {
                String clipboardContent = clipboard.getString();
                int caretPosition = textArea.getCaretPosition();
                textArea.insertText(caretPosition, clipboardContent);
            }
        });
        MenuItem deleteItem = new MenuItem("Delete");
        deleteItem.setAccelerator(KeyCombination.keyCombination("Del"));
        deleteItem.setOnAction(e ->{
            int start = textArea.getSelection().getStart();
            int end = textArea.getSelection().getEnd();
            textArea.replaceText(start, end, "");
        });
        MenuItem selectAllItem = new MenuItem("Select All");
        selectAllItem.setAccelerator(KeyCombination.keyCombination("Ctrl+A"));
        selectAllItem.setOnAction(e -> textArea.selectAll());
//        add edit items to edit
        edit.getItems().addAll(undoItem, new SeparatorMenuItem(), cutItem, copyItem, pasteItem,
                deleteItem, new SeparatorMenuItem(), selectAllItem);
//        add edit to menu bar
        menuBar.getMenus().add(edit);




//        Format Button ->
        Menu format = new Menu("Format");
//        add format to menu bar
        menuBar.getMenus().add(format);

//        View Button ->
        Menu view = new Menu("View");
//        view items
        MenuItem zoomItems = new MenuItem("Zoom");
//        add view items to view
        view.getItems().addAll(zoomItems);
//        add view to menu bar
        menuBar.getMenus().add(view);

//        Help Button ->
        Menu help = new Menu("Help");
        help.getItems().add(new MenuItem("No help found, I tried :/"));

//        add help to menu bar
        menuBar.getMenus().add(help);






//        vbox
        var vbox = new VBox();
//        add both menu bar & text area to vbox
        vbox.getChildren().add(menuBar);
        vbox.getChildren().add(textArea);

//        scene
        var scene = new Scene(vbox);


//        Actions ->
//        Set height & width of text Area
        textArea.prefHeightProperty().bind(scene.heightProperty());
        textArea.prefWidthProperty().bind(scene.widthProperty());







//        Stage
        stage.setTitle(currentNoteName + " - NotePad");
        stage.setScene(scene);
//        set stage width & height
        stage.setWidth(600);
        stage.setHeight(500);
//        set Min stage width & height
        stage.setMinWidth(500);
        stage.setMinHeight(400);
//        show stage
        stage.show();

    }








//    ACTION EVENT METHODS



//    Method to create a new TextArea
    private void newFile(TextArea textArea) {
        textArea.clear();
        currentNoteName = "Untitled"  + " - NotePad";
        updateStageTitle(textArea);
    }


//    Method to update the stage title with the current note name
    private void updateStageTitle(TextArea textArea) {
        Stage stage = (Stage) textArea.getScene().getWindow();
        stage.setTitle(currentNoteName + " - NotePad");
    }


//    method to save default or already-existing file
    private void saveToFile(TextArea textArea) {
        if (currentFile != null) {
            try (FileWriter fileWriter = new FileWriter(currentFile)) {
                fileWriter.write(textArea.getText());
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            saveAsToFile(textArea.getText());
        }
    }


//    method to save a brand new text file
    public void saveAsToFile(String content) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save File");

        // Set the file extension filter to text files
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("Text files (*.txt)", "*.txt");
        fileChooser.getExtensionFilters().add(extFilter);

        // Show the save file dialog
        File file = fileChooser.showSaveDialog(null);

        if (file != null) {
            try (FileWriter fileWriter = new FileWriter(file)) {
                fileWriter.write(content);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void openFile(TextArea textArea) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open File");

        // Set the file extension filter to text files
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("Text files (*.txt)", "*.txt");
        fileChooser.getExtensionFilters().add(extFilter);

        // Show the open file dialog
        File selectedFile = fileChooser.showOpenDialog(null);

        if (selectedFile != null) {
            // Read the content of the selected file and display it in the TextArea
            try (BufferedReader reader = new BufferedReader(new FileReader(selectedFile))) {
                StringBuilder content = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    content.append(line).append("\n");
                }
                textArea.setText(content.toString());
                // Set the currentNoteName to the opened file name
                currentNoteName = selectedFile.getName();
                updateStageTitle(textArea);
                currentFile = selectedFile;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    private void printFile(Stage primaryStage, TextArea textArea) {
        PrinterJob printerJob = PrinterJob.createPrinterJob();

        if (printerJob != null) {
            // Create a printable node, in this case, a TextArea
            TextArea printableNode = new TextArea(textArea.getText());

            // Show the print dialog
            if (printerJob.showPrintDialog(primaryStage)) {
                // Print the content
                if (printerJob.printPage(printableNode)) {
                    printerJob.endJob();
                }
            }
        }
    }

    // Method to cut the selected text from the TextArea and store it in the clipboard
    private void cutText(TextArea textArea) {

    }

    public static void main(String[] args) {
        launch();
    }
}

